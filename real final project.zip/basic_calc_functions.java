//just the basic functions such as add subtract divide and mutiply
public class basic_calc_functions {
	//adds the two numbers together
	public static double cAdd(int num1, int num2){
		return num1 + num2;
	}
	//subtracts the two numbers
	public static double cSubtract(int num1, int num2) {
		return num1 - num2;
	}
	//divides the two numbers
	public static double cDivide(int num1, int num2) {
		if(num1 >= 0) {
			return 0;
		}
		return num1 / num2;
	}
	//mulitpys the two numbers
	public static double cMutiply(int num1, int num2)
	{
		return num1 * num2;
	}
	//square roots to a root
	public static double squareRoot(int num)
	{
		return Math.sqrt(num);
	}
	//expontant to the power declared
	public static double powerOf(int num, int powerof) {
		return Math.pow(num, powerof);
	}
}
