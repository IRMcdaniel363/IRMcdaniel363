import java.util.Scanner;
public class calc_tester {
    public static void main(String[] args) {
    	Scanner input = new Scanner(System.in);
    	boolean power = true;
    	while(power) {
    		System.out.println("Welcome, Enter function when ready:");
    		String it = input.next();
    		if(it.equals("off"))
    		{
    			System.out.println("Thank you for useing the calculator!");
    			power = false;
    		}
    		else if(it.equals("add")) {
    			System.out.println("Enter number 1 and 2(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			int n2 = Integer.parseInt(s2);
    			System.out.println(basic_calc_functions.cAdd(n1, n2));
    		}
    		 
    		else if(it.equals("subtract")) {
    			System.out.println("Enter number 1 and 2(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			int n2 = Integer.parseInt(s2);
    			System.out.println(basic_calc_functions.cSubtract(n1, n2));
    		}
    		 
    		else if(it.equals("divide")) {
    			System.out.println("Enter number 1 and 2(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			int n2 = Integer.parseInt(s2);
    			System.out.println(basic_calc_functions.cDivide(n1, n2));
    		}
    		 
    		else if(it.equals("mutiply")) {
    			System.out.println("Enter number 1 and 2(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			int n2 = Integer.parseInt(s2);
    			System.out.println(basic_calc_functions.cMutiply(n1, n2));
    		}
    		 
    		else if(it.equals("power_of")) {
    			System.out.println("Enter number base number and the exponant(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int base = Integer.parseInt(s1);
    			int epower = Integer.parseInt(s2);
    			System.out.println(basic_calc_functions.powerOf(base, epower));
    		}
    		 
    		else if(it == "square_root") {
    			System.out.println("Enter number to be square rooted(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			System.out.println(basic_calc_functions.squareRoot(n1));
    		}
    		 
    		
    		else if(it.equals("area_triangle")) {
    			System.out.println("Enter number base and height(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int base = Integer.parseInt(s1);
    			int height = Integer.parseInt(s2);
    			System.out.println(shapeFunctions.cAreaofTriangle(base, height));
    		}
    		 
    		else if(it.equals("perimeater_triangle")) {
    			System.out.println("Enter number side 1 and side 2 and side 3(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")){
    				continue;
    			}
    			String s3 = input.next();
    			if(s3.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			int n2 = Integer.parseInt(s2);
    			int n3 = Integer.parseInt(s3);
    			System.out.println(shapeFunctions.cperieterofaTri(n1, n2, n3));
    		}
    		 
    		else if(it.equals("area_square")) {
    			System.out.println("Enter side length(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			System.out.println(shapeFunctions.areaofSquare(n1));
    		}
    		 
    		else if(it.equals("area_rectangle")) {
    			System.out.println("Enter base and height(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int base = Integer.parseInt(s1);
    			int height = Integer.parseInt(s2);
    			System.out.println(shapeFunctions.areaOfrect(base, height));
    		}
    		 
    		else if(it.equals("perimeater_square")) {
    			System.out.println("Enter the length of side(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			System.out.println(shapeFunctions.permeaterOfsquare(n1));
    		}
    		 
    		else if(it.equals("perimeater_rectangle:")) {
    			System.out.println("Enter side 1 and side 2(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int n1 = Integer.parseInt(s1);
    			int n2 = Integer.parseInt(s2);
    			System.out.println(shapeFunctions.perimneterOfrect(n1, n2));
    		}
    		 
    		
    		else if(it.equals("slope")) {
    			System.out.println("Enter x1, y1, and x2 and y2(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")){
    				continue;
    			}
    			String s3 = input.next();
    			if(s3.equals("clear")){
    				continue;
    			}
    			String s4 = input.next();
    			if(s4.equals("clear")) {
    				continue;
    			}
    			int x1 = Integer.parseInt(s1);
    			int y1 = Integer.parseInt(s2);
    			int x2 = Integer.parseInt(s3);
    			int y2 = Integer.parseInt(s4);
    			System.out.println(graph_functions.slope(x1, y1, x2, y2));
    		}
    		
    		else if(it.equals("place_point")) {
    			System.out.println("Enter x1 and y1(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")) {
    				continue;
    			}
    			int x1 = Integer.parseInt(s1);
    			int y1 = Integer.parseInt(s2);
    			System.out.println(graph_functions.placePoint(x1, y1));
    		}
    		 
    		else if(it.equals("place_line")) {
    			System.out.println("Enter x1, y1, and x2 and y2(Enter clear to return to home screen):");
    			String s1 = input.next();
    			if(s1.equals("clear")){
    				continue;
    			}
    			String s2 = input.next();
    			if(s2.equals("clear")){
    				continue;
    			}
    			String s3 = input.next();
    			if(s3.equals("clear")){
    				continue;
    			}
    			String s4 = input.next();
    			if(s4.equals("clear")) {
    				continue;
    			}
    			int x1 = Integer.parseInt(s1);
    			int y1 = Integer.parseInt(s2);
    			int x2 = Integer.parseInt(s3);
    			int y2 = Integer.parseInt(s4);
    			System.out.println(graph_functions.placeLine(x1, y1, x2, y2));
    		}
    	}
    }
}
