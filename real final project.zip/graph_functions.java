//this will really shine with UI
public class graph_functions {
	public static double slope(int point1x, int point1y, int point2x, int point2y) {
		return (point2y - point1y) / (point2x - point1x);
	}
	public static String placePoint(int x, int y) {
		if(x > 0 && y > 0) {
			return "X:" + x + " Y:" + y + " is in quadrant 1.";
		}
		if(x < 0 && y > 0) {
			return "X:" + x + " Y:" + y + " is in quadrant 2.";
		}
		else if(x > 0 && y < 0) {
			return "X:" + x + " Y:" + y + " is in quadrant 4.";
		}
		else if(x < 0 && y < 0) {
			return "X:" + x + " Y:" + y + " is in quadrant 3.";
		}
		else if(x != 0 && y == 0) {
			return "X:" + x + " Y:" + y + " is ont the y axis.";
		}
		else if(x == 0 && y != 0) {
			return "X:" + x + " Y:" + y + " is on the x axis.";
		}
		else {
			return "Your points are X: 0 Y: 0.";
		}
	}
	//places a line
	public static String placeLine(int x1, int y1, int x2, int y2) {
		return "Your line has benn created from X:" + x1 + " y:" + y1 + " and X:" + x2 + " Y:" + y2;
	}
}
