//gives the area and perimeater of the basic functions
public class shapeFunctions {
	//area of a triangle
	public static double cAreaofTriangle(int base, int height) {
		return (base * height) / 2;
	}
	
	//returns the perimeter of a triangle
	public static double cperieterofaTri(int side1, int side2, int side3) {
		return side1 + side2 + side3;
	}
	
	//returns the area of a square
	public static double areaofSquare(int side) {
		return side * side;
	}
	
	//returns the perimeter of a square
	public static double permeaterOfsquare(int side) {
		return side * 4;
	}
	
	//returns the area of a rectangle
	public static double areaOfrect(int base, int height) {
		return base * height;
	}
	
	//returns the permeater of a rectangle
	public static double perimneterOfrect(int base, int height) {
		return (base * 2) + (height * 2);
	}
}
